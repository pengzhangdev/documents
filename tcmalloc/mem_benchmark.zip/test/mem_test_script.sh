#! /system/bin/sh

# malloc benchmark script

TEST_REPORT=/data/mem_benchmark

# don't hang the system when testing. So leave half of free mem.

FREE_MEM=$(($(busybox cat /proc/meminfo | busybox grep MemFree | busybox awk '{print $2}') * 1024))
FREE_MEM=$(($FREE_MEM / 2))  # byte

MEM_ALLOC_MAX=395264 # byte

# MEM_INCR should adjust to the MEM_ALLOC
# IF MEM_ALLOC > 1024 THEN MEM_INCR=1024 ELSE MEM_INCR=16
# MEM_ALLOC += MEM_INCR
MEM_INCR=16

# MEM_INTERATION should adjust to the MEM_ALLOC and FREE_MEM
# MEM_INTERATION=$((FREE_MEM / MEM_ALLOC))
# IF MEM_INTERATION > 1000 THEN MEM_INTERATION=1000
MEM_INTERATION=16

# THREAD_COUNT start with 1 and ends with 16
THREAD_COUNT_MAX=16

echo "start malloc benchmark" > $TEST_REPORT

function start_test()
{
	local thread_count=4
	local mem_alloc=8
	local mem_interation=1
	
	while [ $mem_alloc -lt $MEM_ALLOC_MAX ]
	do	
		if [ $mem_alloc -gt 1024 ]; then
			MEM_INCR=1024
		fi
	
		MEM_INTERATION=$(($FREE_MEM / $mem_alloc))
	
		if [ $MEM_INTERATION -gt 1000 ]; then
			MEM_INTERATION=1000
		fi

		mem_interation=1
		while [ $mem_interation -lt $MEM_INTERATION ]
		do
			echo "mem_alloc=$mem_alloc interation=$mem_interation thread=$thread_count" >> $TEST_REPORT
			setprop libc.tcmalloc.enable 0
			./mem_test $mem_alloc $mem_interation $thread_count >> $TEST_REPORT
			sleep 1
			setprop libc.tcmalloc.enable 1
			./mem_test $mem_alloc $mem_interation $thread_count >> $TEST_REPORT
			echo "" >> $TEST_REPORT
            mem_interation=$(($mem_interation + 1 + $(($mem_interation / 2))))
		done
		
		mem_alloc=$(($mem_alloc + $MEM_INCR))
	done
}

# main:  logic start here

start_test

