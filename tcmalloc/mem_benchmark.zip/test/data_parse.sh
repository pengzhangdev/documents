#! /bin/bash

XY_IDX=2
Z_DL=5
Z_TC=8
LINE_IDX_INC=8

CURR_IDX=1
LAST_X=8

CHART_DATA_FILE=./chart_data

function get_x_y
{
    local line=$1
    local X=0
    X=`echo $line | cut -d '=' -f 2 | cut -d ' ' -f 1`
    Y=`echo $line | cut -d '=' -f 3 | cut -d ' ' -f 1`

    if [[ $X != $LAST_X ]]; then
        LAST_X=$X
        echo "" >> $CHART_DATA_FILE
        echo -n "$X " >> $CHART_DATA_FILE
    fi
}

function build_y
{
    local line=$1
    local X=0

    X=`echo $line | cut -d '=' -f 2 | cut -d ' ' -f 1`
    Y=`echo $line | cut -d '=' -f 3 | cut -d ' ' -f 1`

    if [[ $X != $LAST_X ]]; then
        return 1
    fi

    echo -n " $Y" >> $CHART_DATA_FILE

    return 0
}

function get_z
{
    local line=$1
    local Z=0
    Z=`echo $line | cut -d '=' -f 2 | cut -d ' ' -f 2`

    echo -n "$Z " >> $CHART_DATA_FILE
}


############ main ################

echo -n " "> $CHART_DATA_FILE

cat $1 | while read line
do
    if [[ $((($CURR_IDX - 2) % $LINE_IDX_INC)) == 0 ]]; then
        build_y "$line"
        if [[ $? == 1 ]]; then
            break
        fi
    fi

    CURR_IDX=$(($CURR_IDX + 1))
done

echo "" >> $CHART_DATA_FILE
LAST_X=0
CURR_IDX=1
cat $1 | while read line
do
    if [[ $((($CURR_IDX - 2) %  $LINE_IDX_INC)) == 0 ]]; then
        get_x_y "$line"
    fi

    if [[ $((($CURR_IDX - 8) % $LINE_IDX_INC)) == 0 ]]; then
        get_z "$line"
    fi

    CURR_IDX=$(($CURR_IDX + 1))
done
